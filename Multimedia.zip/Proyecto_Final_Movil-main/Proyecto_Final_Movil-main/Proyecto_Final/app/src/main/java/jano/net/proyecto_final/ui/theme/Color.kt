package jano.net.proyecto_final.ui.theme

import androidx.compose.ui.graphics.Color

val clWhite = Color(0xFFFFFFFF)
val clGray = Color(0xFF353489)

