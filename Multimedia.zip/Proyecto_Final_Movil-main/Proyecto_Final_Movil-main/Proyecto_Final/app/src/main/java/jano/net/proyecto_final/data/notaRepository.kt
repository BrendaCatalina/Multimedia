package jano.net.proyecto_final.data

class notaRepository {
}