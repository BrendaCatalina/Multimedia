package jano.net.proyecto_final.data

interface notaDao {
}