package com.example.inventory

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.example.inventory.ui.theme.Proyecto_FinalTheme
import com.example.inventory.dataNota.notaDb
import com.example.inventory.dataNota.notaRepository
import com.example.inventory.dataTarea.tareaDb
import com.example.inventory.dataTarea.tareaRepository
import com.example.inventory.ui.nota.viewModelNota
import com.example.inventory.ui.tarea.ViewModelTarea

const val REQUEST_PERMISSIONS = 100

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dbNota = Room.databaseBuilder(this, notaDb::class.java, "nota_db").build()
        val daoNota = dbNota.dao
        val repositoryNota = notaRepository(daoNota)
        val viewModelNota = viewModelNota(repositoryNota)

        val dbTarea = Room.databaseBuilder(this, tareaDb::class.java, "tarea_db").build()
        val daoTarea = dbTarea.dao
        val repositoryTarea = tareaRepository(daoTarea)
        val viewModelTarea = ViewModelTarea(repositoryTarea)
        enableEdgeToEdge()
        setContent {
            Proyecto_FinalTheme {
                Nav(viewModelNota, viewModelTarea)
            }
        }

        // Solicitar permisos dinámicamente
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                REQUEST_PERMISSIONS
            )
        }
    }

    // Manejar la respuesta de los permisos
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (!allGranted) {
                Toast.makeText(this, "Se requieren permisos para continuar", Toast.LENGTH_LONG).show()
            }
        }
    }
}
